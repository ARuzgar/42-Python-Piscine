"""
Setup script for ft_package.
"""

from setuptools import setup, find_packages

setup()